const menu1 = (prefix) => {
	return `
╭───────╯•╰───────╮
│        MENU DE FIGURINHAS🖼️
│
├┬➣ ${prefix}f
│└➵ Converte imagem em figu
├┬➣ ${prefix}toimg
│└➵ Converte figu em imagem
╰───────╮•╭───────╯
	`
}

module.exports = { menu1 }