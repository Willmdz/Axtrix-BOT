const menu2 = (prefix) => {
	return `╭───────╯•╰───────╮
│        MENU DE AUDIOS 🎧
│
├┬➣ ${prefix}play
│└➵ Baixa musica do YouTube
╰───────╮•╭───────╯ `
}

exports.menu2 = menu2