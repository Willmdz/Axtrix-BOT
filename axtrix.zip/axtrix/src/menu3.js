const menu3 = (prefix) => {
	return `╭───────╯•╰───────╮
│        MENU DE GRUPOS
│
├┬➣ ${prefix}online
│└➵ Veja quem estar online no grupo
╰───────╮•╭───────╯ `
}

exports.menu3 = menu3