/*
->BOT TOTALMENTE EDITAVEL.
-> QUALQUER DUVIDA ME CHAMA
-> FAÇO BOTS PERSONALIZADOS (DEPENDENDO DO BOT UM VALOR)
wa.me/557182366834

*/


const {
    WAConnection,
    MessageType,
    Presence,
    Mimetype,
    GroupSettingChange
} = require('@adiwajshing/baileys')
//----->ARQUIVOS DA LIB<-----//
const { color, bgcolor } = require('./lib/color')
const { wait, simih, getBuffer, h2k, generateMessageID, getGroupAdmins, getRandom, banner, start, info, success, close } = require('./lib/functions')
const { fetchJson, fetchText } = require('./lib/fetcher')
const { recognize } = require('./lib/ocr')
const level = require("./lib/level");
const premium = require("./lib/premium");
const afk = require("./lib/afk");
const _sewa = require("./lib/sewa");
//----->ARQUIVOS NPM<-----//
const fs = require('fs')
const moment = require('moment-timezone')
const { exec } = require('child_process')
const fetch = require('node-fetch')
const ffmpeg = require('fluent-ffmpeg')
const { removeBackgroundFromImageFile } = require('remove.bg')
//----->DATA BASE<-----//
let register = JSON.parse(fs.readFileSync('./database/user/register.json'))
let _premium = JSON.parse(fs.readFileSync('./database/user/premium.json'));
let sewa = JSON.parse(fs.readFileSync('./database/group/sewa.json'));
let _leveling = JSON.parse(fs.readFileSync('./database/group/leveling.json'))
let mute = JSON.parse(fs.readFileSync('./database/group/mute.json'));
let _level = JSON.parse(fs.readFileSync('./database/user/level.json'))
let autofigu = JSON.parse(fs.readFileSync('./database/autofigu.json'))
let _afk = JSON.parse(fs.readFileSync('./database/user/afk.json'));
let antilink = JSON.parse(fs.readFileSync('./database/group/antilink.json'));
const welkom = JSON.parse(fs.readFileSync('./src/welkom.json'))
const nsfw = JSON.parse(fs.readFileSync('./src/nsfw.json'))
const samih = JSON.parse(fs.readFileSync('./src/simi.json'))
const setting = JSON.parse(fs.readFileSync('./src/settings.json'))
//----->MENUS<-----//
const menu1 = require('./src/menu1')
const menu2 = require('./src/menu2')
const menu3 = require('./src/menu3')
//----->VERIFICADO<-----//
let errorImg = 'https://i.ibb.co/FBm52Pt/1e0fe6a08b67.jpg'
//----->PREFIX<-----//
prefix = setting.prefix
blocked = []

function kyun(seconds){
  function pad(s){
    return (s < 10 ? '0' : '') + s;
  }
  var hours = Math.floor(seconds / (60*60));
  var minutes = Math.floor(seconds % (60*60) / 60);
  var seconds = Math.floor(seconds % 60);

  //return pad(hours) + ':' + pad(minutes) + ':' + pad(seconds)
  return `${pad(hours)} Jam ${pad(minutes)} Menit ${pad(seconds)} Detik`
}

async function starts() {
	const client = new WAConnection()
	client.logger.level = 'warn'
	console.log(banner.string)
	client.on('qr', () => {
		console.log(color('[','white'), color('!','red'), color(']','white'), color(' Scan the qr code above'))
	})

	fs.existsSync('./axtrix.json') && client.loadAuthInfo('./axtrix.json')
	client.on('connecting', () => {
		start('2', 'Connecting...')
	})
	client.on('open', () => {
		success('2', 'Connected')
	})
	await client.connect({timeoutMs: 30*1000})
        fs.writeFileSync('./axtrix.json', JSON.stringify(client.base64EncodedAuthInfo(), null, '\t'))

	client.on('group-participants-update', async (anu) => {
		if (!welkom.includes(anu.jid)) return
		try {
			const mdata = await client.groupMetadata(anu.jid)
			console.log(anu)
			if (anu.action == 'add') {
				num = anu.participants[0]
				try {
					ppimg = await client.getProfilePicture(`${anu.participants[0].split('@')[0]}@c.us`)
				} catch {
					ppimg = 'https://i0.wp.com/www.gambarunik.id/wp-content/uploads/2019/06/Top-Gambar-Foto-Profil-Kosong-Lucu-Tergokil-.jpg'
				}
				teks = `Ola @${num.split('@')[0]}\nSeja bem vindo ao *${mdata.subject}*`
				let buff = await getBuffer(ppimg)
				client.sendMessage(mdata.id, buff, MessageType.image, {caption: teks, contextInfo: {"mentionedJid": [num]}})
			} else if (anu.action == 'remove') {
				num = anu.participants[0]
				try {
					ppimg = await client.getProfilePicture(`${num.split('@')[0]}@c.us`)
				} catch {
					ppimg = 'https://i0.wp.com/www.gambarunik.id/wp-content/uploads/2019/06/Top-Gambar-Foto-Profil-Kosong-Lucu-Tergokil-.jpg'
				}
				teks = `Bye Bye @${num.split('@')[0]}👋`
				let buff = await getBuffer(ppimg)
				client.sendMessage(mdata.id, buff, MessageType.image, {caption: teks, contextInfo: {"mentionedJid": [num]}})
			}
		} catch (e) {
			console.log('Error : %s', color(e, 'red'))
		}
	})

	client.on('CB:Blocklist', json => {
            if (blocked.length > 2) return
	    for (let i of json[1].blocklist) {
	    	blocked.push(i.replace('c.us','s.whatsapp.net'))
	    }
	})

	client.on('chat-update', async (mek) => {
		try {
            if (!mek.hasNewMessage) return
            mek = mek.messages.all()[0]
			if (!mek.message) return
			if (mek.key && mek.key.remoteJid == 'status@broadcast') return
//			if (mek.key.fromMe) return
			global.prefix
			global.blocked
			const content = JSON.stringify(mek.message)
			const from = mek.key.remoteJid
			const type = Object.keys(mek.message)[0]
			const apiKey = setting.apiKey 
			const nomeB = setting.nomeBot
			const { text, extendedText, contact, location, liveLocation, image, video, sticker, document, audio, product } = MessageType
			const time = moment.tz('Asia/Jakarta').format('DD/MM HH:mm:ss')
			body = (type === 'conversation' && mek.message.conversation.startsWith(prefix)) ? mek.message.conversation : (type == 'imageMessage') && mek.message[type].caption.startsWith(prefix) ? mek.message[type].caption : (type == 'videoMessage') && mek.message[type].caption.startsWith(prefix) ? mek.message[type].caption : (type == 'extendedTextMessage') && mek.message[type].text.startsWith(prefix) ? mek.message[type].text : (type == 'listResponseMessage') && mek.message[type].singleSelectReply.selectedRowId ? mek.message[type].singleSelectReply.selectedRowId : (type == 'buttonsResponseMessage') && mek.message[type].selectedButtonId ? mek.message[type].selectedButtonId : ''
			budy = (type === 'conversation') ? mek.message.conversation : (type === 'extendedTextMessage') ? mek.message.extendedTextMessage.text : ''
			const command = body.slice(1).trim().split(/ +/).shift().toLowerCase()
			const args = body.trim().split(/ +/).slice(1)
			const isCmd = body.startsWith(prefix)
			const q = args.join(' ') 
			
					let senderr = mek.key.fromMe ? client.user.jid : mek.key.remoteJid.endsWith('@g.us') ? mek.participant : mek.key.remoteJid 

			mess = {
				wait: '[❗] AGUARDE, ESTOU FAZENDO [❗]',
				success: 'Pronto, ta na mão ️',
				error: {
					stick: '❌ Falha, ocorreu um erro ao converter a imagem em um adesivo ❌',
					Iv: '❌ Link inválido ❌'
				},
				only: {
					group: '❌ Este comando só pode ser usado em grupos! ❌',
					ownerG: '❌ Este comando só pode ser usado pelo grupo proprietário! ❌',
					ownerB: '❌ Este comando só pode ser usado pelo proprietário do bot! ❌',
					admin: '❌ Este comando só pode ser usado por administradores de grupo! ❌',
					Badmin: '❌ Este comando só pode ser usado quando o bot é um administrador! ❌'
				}
			}

			const botNumber = client.user.jid
			const ownerNumber = [`${setting.ownerNumber}@s.whatsapp.net`]
			const isGroup = from.endsWith('@g.us')
			const sender = mek.key.fromMe ? client.user.jid : mek.key.remoteJid.endsWith('@g.us') ? mek.participant : mek.key.remoteJid
			const groupMetadata = isGroup ? await client.groupMetadata(from) : ''
			const groupMembers = isGroup ? groupMetadata.participants : ''
			const groupName = isGroup ? groupMetadata.subject : ''
		    const groupAdmins = isGroup ? getGroupAdmins(groupMembers) : ''
			const groupId = isGroup ? groupMetadata.jid : ''
			const conts = mek.key.fromMe ? client.user.jid : client.contacts[sender] || { notify: jid.replace(/@.+/, '') }
			const pushname = mek.key.fromMe ? client.user.name : conts.notify || conts.vname || conts.name || '-'
			const isBotGroupAdmins = groupAdmins.includes(botNumber) || false
			const isGroupAdmins = groupAdmins.includes(sender) || false
			const isNsfw = isGroup ? nsfw.includes(from) : false
			const isSimi = isGroup ? samih.includes(from) : false
			const isOwner = ownerNumber.includes(sender)
		    const isRegister = register.includes(sender)
            const isPremium = premium.checkPremiumUser(sender, _premium)
            const isSewa = _sewa.checkSewaGroup(from, sewa)
            const isAfkOn = afk.checkAfkUser(sender, _afk)
            const isLevelingOn = isGroup ? _leveling.includes(from) : false
            const isMuted = isGroup ? mute.includes(from) : false
            const isAutofigu = isGroup ? autofigu.includes(from) : false		     
            const isAntiLink = isGroup ? antilink.includes(from) : false
            const isWelkom = isGroup ? welkom.includes(from) : false
			
selectedButton = (type == 'buttonsResponseMessage') ? mek.message.buttonsResponseMessage.selectedButtonId : ''

responseButton = (type == 'listResponseMessage') ? mek.message.listResponseMessage.title : ''

const gcount = setting.gcount
        
const listmsg = (from, title, desc, list) => { // ngeread nya pake rowsId, jadi command nya ga keliatan
let po = client.prepareMessageFromContent(from, {"listMessage": {"title": title,"description": desc,"buttonText": "Escolha aqui","footerText": "lista","listType": "SINGLE_SELECT","sections": list}}, {})
return client.relayWAMessage(po, {waitForAck: true})
}
const enviar = (teks) => {
client.sendMessage(from, teks, text,  {quoted: mek, contextInfo: {"mentionedJid": [sender]}})
} 
const isUrl = (url) => {
return url.match(new RegExp(/https?:\/\/(www\.)?[-a-zA-Z0-9@:%._+~#=]{1,256}\.[a-zA-Z0-9()]{1,6}\b([-a-zA-Z0-9()@:%_+.~#?&/=]*)/, 'gi'))
}
const reply = (teks) => {
client.sendMessage(from, teks, text, {quoted:mek})
}
const sendMess = (hehe, teks) => {
client.sendMessage(hehe, teks, text)
}
function jsonformat(string) {
return JSON.stringify(string, null, 2)
}
const mentions = (teks, memberr, id) => {
(id == null || id == undefined || id == false) ? client.sendMessage(from, teks.trim(), extendedText, {contextInfo: {"mentionedJid": memberr}}) : client.sendMessage(from, teks.trim(), extendedText, {quoted: mek, contextInfo: {"mentionedJid": memberr}})
}
const freply = { key: { fromMe: false, participant: `0@s.whatsapp.net`, ...(from ? { remoteJid: '16504228206@s.whatsapp.net' } : {}) }, message: { "contactMessage": { "displayName": `${pushname}`, "vcard": `BEGIN:VCARD\nVERSION:3.0\nN:XL;${pushname},;;;\nFN:${pushname},\nitem1.TEL;waid=${senderr.split('@')[0]}:${senderr.split('@')[0]}\nitem1.X-ABLabel:Ponsel\nEND:VCARD`, "jpegThumbnail":fs.readFileSync('./media/Nakano.jpg')
}}}
const math = (teks) => {
return Math.floor(teks)
}
const sendFileFromUrl = async(link, type, options) => {
hasil = await getBuffer(link)
client.sendMessage(from, hasil, type, options).catch(e => {
fetch(link).then((hasil) => {
client.sendMessage(from, hasil, type, options).catch(e => {
client.sendMessage(from, { url : link }, type, options).catch(e => {
reply('_[ ! ] Erro ao baixar e enviar mídia_')
console.log(e)
})
})
})
})
}

//eval EXECUTAR COMANDOS 
if (budy.startsWith('>')){
if (!isOwner) return reply(mess.only.owner)
try {
let evaled = await eval(budy.slice(2))
if (typeof evaled !== 'string') evaled = require('util').inspect(evaled)
await reply(evaled)
//client.sendMessage(from, JSON.stringify(eval(body.slice(6))). text) // SO SE QUISER
} catch (err) {
m = String(err)
await reply(m)
}
}
if (budy.startsWith('=>')){
if (!isOwner) return reply('somente meu criador')
var konsol = budy.slice(3)
Return = (sul) => {
var sat = JSON.stringify(sul, null, 2)
bang = util.format(sat)
if (sat == undefined){
bang = util.format(sul)
}
return reply(bang)
}
try {
reply(util.format(eval(`;(async () => { ${konsol} })()`)))
console.log('\x1b[1;37m>', '[', '\x1b[1;32mEXEC\x1b[1;37m', ']', time, color(">", "green"), 'from', color(sender.split('@')[0]), 'args :', color(args.length))
} catch(e){
  reply(String(e))
}
}
if (body.startsWith('$')) {
if (!q && !isOwner) return enviar('somente meu criador')
exec(q, (err, stdout) => {
if(err) return reply(`${err}`)
if (stdout) {
reply(stdout)
}
})
}




    
/********** BOTÕES **********/
const sendButImage = async(id, text1, desc1, gam1, but = [], options = {}) => {
kma = gam1
mhan = await client.prepareMessage(from, kma, image, {thumbnail: null})
const buttonMessages = {
imageMessage: mhan.message.imageMessage,
contentText: text1,
footerText: desc1,
buttons: but,
headerType: 4
}
client.sendMessage(id, buttonMessages, MessageType.buttonsMessage, options)
}

const sendButVideo = async(id, text1, desc1, vid1, but = [], options = {}) => {
kma = vid1
mhan = await client.prepareMessage(from, kma, video)
const buttonMessages = {videoMessage: mhan.message.videoMessage, contentText: text1, footerText: desc1, buttons: but, headerType: 5}
client.sendMessage(id, buttonMessages, MessageType.buttonsMessage, options)
}

const sendButMessage = (id, text1, desc1, but = [], options = {}) => {
const buttonMessage = {
contentText: text1,
footerText: desc1,
buttons: but,
headerType: 1
}
client.sendMessage(id, buttonMessage, MessageType.buttonsMessage, options)
}

			
 const levelRole = level.getLevelingLevel(sender, _level)
        var role = 'Bronze  I🥉'
        if (levelRole <= 5) {
            role = 'Bronze II🥉'
        } else if (levelRole <= 10) {
            role = 'Bronze II🥉'
        } else if (levelRole <= 15) {
            role = 'Prata I🥈'
        } else if (levelRole <= 20) {
            role = 'Prata II🥈'
        } else if (levelRole <= 21) {
            role = 'Prata III🥈'
        } else if (levelRole <= 22) {
            role = 'Ouro I🥇'
        } else if (levelRole <= 23) {
            role = 'Ouro II🥇'
        } else if (levelRole <= 24) {
            role = 'Ouro IOuro II🥇'
        } else if (levelRole <= 26) {
            role = 'Campeão I🏆'
        } else if (levelRole <= 28) {
            role = 'Campeão II🏆'
        } else if (levelRole <= 30) {
            role = 'Campeão III🏆' 
        } else if (levelRole <= 32) {
            role = 'Diamante I 💎'
        } else if (levelRole <= 34) {
            role = 'Diamante II💎'
        } else if (levelRole <= 36) {
            role = 'Diamante III💎'
        } else if (levelRole <= 38) {
            role = 'Mestre I 🐂'
        } else if (levelRole <= 40) {
            role = 'Mestre II🐂'
        } else if (levelRole <= 42) {
            role = 'Mestre III🐂'
        } else if (levelRole <= 44) {
            role = 'Mítico🔮'
        } else if (levelRole <= 46) {
            role = 'Glória Mítica🔮'
        } else if (levelRole >= 50) {
            role = 'Grande Mestre🛐'
        } 
        
       // FUNÇÃO LEVELING
       if (isGroup && !mek.key.fromMe && !level.isGained(sender) && isLevelingOn) {
       try {
       level.addCooldown(sender)
       const checkATM = atm.checkATMuser(sender, _uang)
       if (checkATM === undefined) atm.addATM(sender, _uang)
       const uangsaku = Math.floor(Math.random() * (15 - 25 + 1) + 20)
       atm.addKoinUser(sender, uangsaku, _uang)
       const currentLevel = level.getLevelingLevel(sender, _level)
       const amountXp = Math.floor(Math.random() * (15 - 25 + 1) + 20)
       const requiredXp = 10 * Math.pow(currentLevel, 2) + 50 * currentLevel + 100
       level.addLevelingXp(sender, amountXp, _level)
       if (requiredXp <= level.getLevelingXp(sender, _level)) {
       level.addLevelingLevel(sender, 1, _level)
       const userLevel = level.getLevelingLevel(sender, _level)
       const fetchXp = 10 * Math.pow(userLevel, 2) + 50 * userLevel + 100
       reply(`
⊷════❖LEVEL UP❖════⊷

╭━═══════════════⊷
┃╭══════════════⊷
┃│         ⬩Ｌｅｖｅｌ 
┃│⪧ Nome : ${pushname}
┃│⪧ Xp : ${level.getLevelingXp(sender, _level)} / ${fetchXp}
┃│⪧ Level : ${currentLevel} -> ${level.getLevelingLevel(sender, _level)} 🆙 
┃│⪧ Patente: ${role}
┃╰═════════════⊷
╰━═══════════════⊷`)
} 
       } catch (err) {
       console.error(err)
}
}

menu =`
╭───────╯•╰───────╮
│➸ NOME: Axtrix
│➸ PREFIX: ${prefix}
│➸ CRIADOR: WILL
│➸ USUARIO: ${pushname}
│
├────────────────╯
│
│-> ${prefix}menu1
│
│➥ MENU DE FIGURINHAS
├─────────────────
│
│-> ${prefix}menu2
│
│➥ MENU DE AUDIOS
├─────────────────
│
│-> ${prefix}menu3
│
│➥ MENU DE IMAGENS
├─────────────────
│
│-> ${prefix}menu4
│
│➥ MENU DE JOGOS
├─────────────────
│
│-> ${prefix}menu5
│
│➥ MENU DE LOGOS
├─────────────────
│
│╭──────────────╮
││
││ MEU CANAL
││https://www.youtube.com/c/WillDevJS
│╰──────────────╯
╰───────╮•╭───────╯

`



			colors = ['red','white','black','blue','yellow','green']
			const isMedia = (type === 'imageMessage' || type === 'videoMessage')
			const isQuotedImage = type === 'extendedTextMessage' && content.includes('imageMessage')
			const isQuotedVideo = type === 'extendedTextMessage' && content.includes('videoMessage')
			const isQuotedSticker = type === 'extendedTextMessage' && content.includes('stickerMessage')
			if (!isGroup && isCmd) console.log('\x1b[1;31m~\x1b[1;37m>', '[\x1b[1;32mEXEC\x1b[1;37m]', time, color(command), 'from', color(sender.split('@')[0]), 'args :', color(args.length))
			if (!isGroup && !isCmd) console.log('\x1b[1;31m~\x1b[1;37m>', '[\x1b[1;31mRECV\x1b[1;37m]', time, color('Message'), 'from', color(sender.split('@')[0]), 'args :', color(args.length))
			if (isCmd && isGroup) console.log('\x1b[1;31m~\x1b[1;37m>', '[\x1b[1;32mEXEC\x1b[1;37m]', time, color(command), 'from', color(sender.split('@')[0]), 'in', color(groupName), 'args :', color(args.length))
			if (!isCmd && isGroup) console.log('\x1b[1;31m~\x1b[1;37m>', '[\x1b[1;31mRECV\x1b[1;37m]', time, color('Message'), 'from', color(sender.split('@')[0]), 'in', color(groupName), 'args :', color(args.length))
			let authorname = client.contacts[from] != undefined ? client.contacts[from].vname || client.contacts[from].notify : undefined	
			if (authorname != undefined) { } else { authorname = groupName }	
			
			function addMetadata(packname, author) {	
				if (!packname) packname = 'WABot'; if (!author) author = 'Bot';	
				author = author.replace(/[^a-zA-Z0-9]/g, '');	
				let name = `${author}_${packname}`
				if (fs.existsSync(`./src/stickers/${name}.exif`)) return `./src/stickers/${name}.exif`
				const json = {	
					"sticker-pack-name": packname,
					"sticker-pack-publisher": author,
				}
				const littleEndian = Buffer.from([0x49, 0x49, 0x2A, 0x00, 0x08, 0x00, 0x00, 0x00, 0x01, 0x00, 0x41, 0x57, 0x07, 0x00])	
				const bytes = [0x00, 0x00, 0x16, 0x00, 0x00, 0x00]	

				let len = JSON.stringify(json).length	
				let last	

				if (len > 256) {	
					len = len - 256	
					bytes.unshift(0x01)	
				} else {	
					bytes.unshift(0x00)	
				}	

				if (len < 16) {	
					last = len.toString(16)	
					last = "0" + len	
				} else {	
					last = len.toString(16)	
				}	

				const buf2 = Buffer.from(last, "hex")	
				const buf3 = Buffer.from(bytes)	
				const buf4 = Buffer.from(JSON.stringify(json))	

				const buffer = Buffer.concat([littleEndian, buf2, buf3, buf4])	

				fs.writeFile(`./src/stickers/${name}.exif`, buffer, (err) => {	
					return `./src/stickers/${name}.exif`	
				})	

			}
//----------------->INICIO DOS COMANDOS<-----------------//
			switch(command) {
case 'menu1':
client.sendMessage(from, menu1.menu1(prefix, pushname), text)
break
case 'menu2':
client.sendMessage(from, menu2.menu2(prefix, pushname), text)
break
case 'menu3':
client.sendMessage(from, menu3.menu3(prefix, pushname), text)
break
case 'menu': case 'help': case 'meni': case 'bot': case 'men9': case 'men':
buttons = [{buttonId: `${prefix}comandos`,buttonText:{displayText: 'Obrigado Bot'},type:1}]
imageMsg = (await client.prepareMessageMedia(fs.readFileSync(`./media/Menu.jpg`), 'imageMessage', {thumbnail: fs.readFileSync(`./media/Menu.jpg`)})).imageMessage
buttonsMessage = {
contentText: `${menu}`,
footerText: 'Obs : Se você usar Wa GB ou não aparecer os botões, digite ${prefix}comandos', imageMessage: imageMsg,
buttons: buttons,
headerType: 4
}
prep = await client.prepareMessageFromContent(from,{buttonsMessage},{quoted: freply})
client.relayWAMessage(prep)
break
/*case 'comandos':
const rows = [
{title: 'MENU DE FIGURIHAS📋', description: " ", rowId:`${prefix}menu1`}, {title: 'MENU DE AUDIOS 🔊', description: " ", rowId:`${prefix}menu2`}]
const sections = [{title: "Section 1", rows: rows}]
const button = {
buttonText: 'Clique aqui!',
description: "MENU DE LISTA 📃",
sections: sections,
listType: 1
}
client.sendMessage(from, button, MessageType.listMessage)
break*/
//----------------->COMANDOS DE AUDIO<-----------------//
case 'play':
if (args.length < 1) return enviar(`tente usar !play Ela nunca me amou`)
teks = args.join(' ')
anu = await fetchJson("https://lordgcs-api.herokuapp.com/api/yt/playmp4?query=" + teks + "&apikey=APIKEY");
imagePlay = await getBuffer(anu.thumb)
sendButImage(from, `*_Titulo: ${anu.title}_*`,
` *Visualizações: ${anu.views}*\n *Link do canal: ${anu.channel}*\n *Data da publicação: ${anu.published}*`, imagePlay,
[{buttonId: `${prefix}play1 ${q}`, buttonText: {displayText: `Audio`}, type: 1},
{buttonId: `${prefix}s ${q}`, buttonText: {displayText: `Video`}, type: 1},
{buttonId: `${prefix}play3 ${q}`, buttonText: {displayText: `Documanto`}, type: 1}], {quoted: mek});
break
case 'play1':
client.updatePresence(from, Presence.composing) 
if (args.length < 1) return enviar("BU")
await enviar("LILI")
await fetchJson(`http://api-exteam.herokuapp.com/api/download/ytmp3?url=https://youtu.be/CDGMB6m&apikey=RllWrQgM=`).then(result => {
client.sendMessage(from, {url: anu.result[0].link}, MessageType.audio, {quoted: mek, mimetype: 'audio/mp4'}).catch(err => enviar("LULU"));
client.sendMessage(from, {url: result.resultado.thumb}, MessageType.image, {quoted: mek, thumbnail: null, caption: linguagem.playResult(result)}).catch(err => enviar("LALA"));
}).catch(err => {
enviar("ERROR");
console.log('Error : %s', color(err, 'red'))
})
break
case 'teste1':
if (args.length <1) return enviar("Cade o link da musica em?")
reply(mess.wait)
nomes = args.join(' ')
anu = await fetchJson(`http://api-exteam.herokuapp.com/api/download/ytmp3?url=https://youtu.be/${nomes}&apikey=RllWrQgM`)
sendFileFromUrl(result.title)
break
case 'play3':
if (args.length <1) return reply('cade o nome da musica amigo(a)')
reply(mess.espere)
links = args.join(' ')
anu = await fetchJson(`http://api-exteam.herokuapp.com/api/download/ytmp3?url=https://youtu.be/${links}&apikey=RllWrQgM`);
sendFileFromUrl(anu.url, document, {mimetype: 'audio/mp4', quoted: mek});
break
case 's':
if (args.length <1) return reply('cade o nome da musica amigo(a)')
reply(mess.wait)
huhu = args.join(' ')
anu = await fetchJson(`https://lordgcs-api.herokuapp.com/api/yt/playmp4?query=${huhu}&apikey=APIKEY`);
sendFileFromUrl(anu.url, video, {quoted: mek})
break
//----------------->COMANDOS DE GRUPOS<-----------------//
case 'kick':
if (!isOwner) return reply('so meu dono.')
if (isPremium) return reply(`desculpa, esse comando foi banido temporariamente para tirar o risco do bot levar ban no número 😔`)
if (!isGroupAdmins && !isOwner)return reply(mess.admin)
if (!isGroup) return reply(mess.only.group)
kick(from, mentionUser)
break
case 'add':
if (!isGroup) return reply(mess.only.group)
if (!isGroupAdmins) return reply(mess.only.admin)
if (!isBotGroupAdmins) return reply(mess.only.Badmin)
if (args.length < 1) return reply('Yang mau di add jin ya?')
if (args[0].startsWith('08')) return reply('Gunakan kode negara mas')
try {
num = `${args[0].replace(/ /g, '')}@s.whatsapp.net`
client.groupAdd(from, [num])
} catch (e) {
console.log('Error :', e)
reply('Gagal menambahkan target, mungkin karena di private')
}
break
case 'rebaixar':
if (!isGroup) return reply(mess.only.group())
if (!isGroupAdmins && !isOwner)return reply(ptbr.admin())
if (!isBotGroupAdmins) return reply(ptbr.Badmin())
mentioned = mek.message.extendedTextMessage.contextInfo.mentionedJid
if (mentioned.length !== 0){
client.groupDemoteAdmin(from, mentioned)
// .then((res) => reply(jsonformat(res)))
//   .catch((err) => reply(jsonformat(err)))
} else if (isQuotedMsg) {
if (quotedMsg.sender === ownerNumber) return reply(`Tidak bisa kick Owner`)
client.groupDemoteAdmin(from, [quotedMsg.sender])
// .then((res) => reply(jsonformat(res)))
//   .catch((err) => reply(jsonformat(err)))
} else if (!isNaN(args[1])) {
client.groupDemoteAdmin(from, [args[1] + '@s.whatsapp.net'])
//.then((res) => reply(jsonformat(res)))
//  .catch((err) => reply(jsonformat(err)))
} else {
reply(`Use dessa forma: ${prefix}rebaixar @menção para rebaixar um integrante do grupo`)
}
break
case 'promover':
if (!isGroup) return reply(mess.only.group())
if (!isGroupAdmins && !isOwner)return reply(ptbr.admin())
if (!isBotGroupAdmins) return reply(ptbr.Badmin())
mentioned = mek.message.extendedTextMessage.contextInfo.mentionedJid
if (mentioned.length !== 0){
client.groupMakeAdmin(from, mentioned)
// .then((res) => reply(jsonformat(res)))
//   .catch((err) => reply(jsonformat(err)))
} else if (isQuotedMsg) {
client.groupMakeAdmin(from, [quotedMsg.sender])
//.then((res) => reply(jsonformat(res)))
//  .catch((err) => reply(jsonformat(err)))
} else if (!isNaN(args[1])) {
client.groupMakeAdmin(from, [args[1] + '@s.whatsapp.net'])
// .then((res) => reply(jsonformat(res)))
//    .catch((err) => reply(jsonformat(err)))
} else {
reply(`Use dessa forma: ${prefix}promover @menção para promover um integrante do grupo`)
}
break
case 'setgrupname':
if (!isGroup) return reply(mess.only.group)
if (!isBotGroupAdmins) return 
if (args.length == 0) return reply(`Penggunaan ${prefix}setgrupname name`)
client.groupUpdateSubject(from, q)
.then((res) => reply(jsonformat(res)))
.catch((err) => reply(jsonformat(err)))
break
case 'setdesc':
if (!isGroup) return reply(mess.only.group)
if (!isBotGroupAdmins) return reply(mess.only.Badmin)
if (args.length == 0)  return reply(`Penggunaan ${prefix}setdesc desc`)
client.groupUpdateDescription(from, q)
.then((res) => reply(jsonformat(res)))
.catch((err) => reply(jsonformat(err)))
break
case 'setppgrup':
case 'setppgrup':
if (!isGroup) return reply(mess.only.group)
if (!isBotGroupAdmins) return reply(mess.only.Badmin)
if (isQuotedImage) {
let encmedia = isQuotedImage ? JSON.parse(JSON.stringify(mek).replace('quotedM', 'm')).message.extendedTextMessage.contextInfo : mek
let media = await client.downloadMediaMessage(encmedia)
client.updateProfilePicture(from, media)
.then((res) => reply(jsonformat(res)))
.catch((err) => reply(jsonformat(err)))
} else {
reply(`Envie ou marque uma imagem com uma legenda ${prefix}setppgrup`)
}
break
case 'afk': 
if (!isGroup) return reply(mess.only.group)
if (isAfkOn) return reply('Nossa, se você quiser Afk, não entre aqui')
const reason = q ? q : 'Nothing.'
afk.addAfkUser(sender, time, reason, _afk)
const aluty = `Recurso AFK ativado com sucesso *!*\n\n➸ *Nome do usuário*: ${pushname}\n➸ *Razão*: ${reason}`
reply(aluty)
break
case 'linkgroup': case 'linkgrup': case 'linkgc': case 'linkgp': case 'link':
if (!isGroup) return reply(mess.only.group)
if (!isBotGroupAdmins) return reply(mess.only.Badmin)
linkgc = await client.groupInviteCode (from)
yeh = `https://chat.whatsapp.com/${linkgc} aqui esta o link acima\n\nlink do grupo *${groupName}*`
client.sendMessage(from, yeh, text, {quoted: mek})
break
case 'infogrup': case 'grupoinfo': case 'infogrouup': case 'grupinfo': case 'groupinfo': case 'infogp': case 'gpinfo':
if (!isGroup) return reply(mess.only.group)
try {
var pic = await client.getProfilePicture(from)
} catch {
var pic = 'https://i.ibb.co/Tq7d7TZ/age-hananta-495-photo.png'
}
let ingfo = `*G R O U P I N F O*\n\n*Nome :* ${groupName}\n*ID Grup :* ${from}\n*Fez :* ${moment(`${groupMetadata.creation}` * 1000).tz('America/Sao_Paulo').format('DD/MM/YYYY HH:mm:ss')}\n*DONO DO GRUPO :* @${groupMetadata.owner.split('@')[0]}\n*Número de Administradores :* ${groupAdmins.length}\n*Número de participantes :* ${groupMembers.length}\n*Bem-vindo :* ${isWelkom ? '✅' : '❎'}\n*AntiLink :* ${isAntiLink ? '✅' : '❎'}\n*Desc :* \n${groupMetadata.desc}`
client.sendMessage(from, await getBuffer(pic), image, {quoted: mek, caption: ingfo, contextInfo: {"mentionedJid": [groupMetadata.owner.replace('@c.us', '@s.whatsapp.net')]}})
break
case 'tagall': case 'marcar':
if (!isGroup) return reply(mess.only.group)
if (!isGroupAdmins) return reply(mess.only.admin)
let arr = [];
let txti = `*[ MARQUEI TODOS ]*\n\n${q ? q : ''}\n\n`
for (let i of groupMembers){
txti += ` @${i.jid.split("@")[0]}\n`
arr.push(i.jid)
}
mentions(txti, arr, true)
break
case '=>':
if (!isOwner) return 
var konsol = budy.slice(3)
try {
enviar(util.format(eval(`;(async () => { ${konsol} })()`)))
console.log('\x1b[1;37m>', '[', '\x1b[1;32mEXEC\x1b[1;37m', ']', color(">", "green"), 'from', color(sender.split('@')[0]), 'args :', color(args.length))
} catch(e){
enviar(String(e))
}
break
case 'f': case 's': case 'sticker': case 'figu': case 'fig':
if ((isMedia && !mek.message.videoMessage || isQuotedImage) && args.length == 0) {
const encmedia = isQuotedImage ? JSON.parse(JSON.stringify(mek).replace('quotedM','m')).message.extendedTextMessage.contextInfo : mek
const media = await client.downloadAndSaveMediaMessage(encmedia)                                     
rano = getRandom('.webp')
await ffmpeg(`./${media}`)
.input(media)
.on('start', function (cmd) {
console.log(`Started : ${cmd}`)
})
.on('error', function (err) {
console.log(`Error : ${err}`)
exec(`webpmux -set exif ${addMetadata(' ', ' ')} ${rano} -o ${rano}`, async (error) => {
fs.unlinkSync(media)
reply('espere')
})
})
exec(`ffmpeg -i ${media} -vcodec libwebp -filter:v fps=fps=15 -lossless 1 -loop 0 -preset default -an -vsync 0 -s 800:800 ${rano}`, (err) => {
fs.unlinkSync(media)
buffer = fs.readFileSync(rano)
client.sendMessage(from, buffer, sticker, {quoted: mek})
fs.unlinkSync(rano)
})
} else if ((isMedia && mek.message.videoMessage.seconds < 11 || isQuotedVideo && mek.message.extendedTextMessage.contextInfo.quotedMessage.videoMessage.seconds < 11) && args.length == 0) {
const encmedia = isQuotedVideo ? JSON.parse(JSON.stringify(mek).replace('quotedM','m')).message.extendedTextMessage.contextInfo : mek
const media = await client.downloadAndSaveMediaMessage(encmedia)
rano = getRandom('.webp')
reply('espere')
await ffmpeg(`./${media}`)
.inputFormat(media.split('.')[1])
.on('start', function (cmd) {
console.log(`Started : ${cmd}`)
})
.on('error', function (err) {
console.log(`Error : ${err}`)
exec(`webpmux -set exif ${addMetadata(' ', ' ')} ${rano} -o ${rano}`, async (error) => {
fs.unlinkSync(media)
tipe = media.endsWith('.mp4') ? 'video' : 'gif'
reply(`Falha na conversão de ${tipe} para sticker`)
})
})
exec(`ffmpeg -i ${media} -vcodec libwebp -filter:v fps=fps=15 -lossless 1 -loop 0 -preset default -an -vsync 0 -s 200:200 ${rano}`, (err) => {
fs.unlinkSync(media)
buffer = fs.readFileSync(rano)
client.sendMessage(from, buffer, sticker, {quoted: mek})
fs.unlinkSync(rano)
})
} else {
reply(`Você precisa enviar ou marcar uma imagem ou vídeo com no máximo 10 segundos`)
}
break
case 'toimg':
if (!isQuotedSticker) return reply('marque o sticker')
reply(mess.wait)
encmedia = JSON.parse(JSON.stringify(mek).replace('quotedM','m')).message.extendedTextMessage.contextInfo
media = await client.downloadAndSaveMediaMessage(encmedia)
ran = getRandom('.png')
exec(`ffmpeg -i ${media} ${ran}`, (err) => {
fs.unlinkSync(media)
if (err) return reply('Falha ao converter sticker em imagem, marque ela com !tovid')
buffer = fs.readFileSync(ran)
client.sendMessage(from, buffer, image, {quoted: mek, caption: 'Pronto'})
fs.unlinkSync(ran)
})
break
case 'letra':
if (args.length <1) return reply("cade o nome da musica?")
reply(mess.wait)
link = args.join(' ')
anu = await fetchJson(`https://lordgcs-api.herokuapp.com/api/music/liriklagu?query=${link}&apikey=APIKEY`);
client.sendMessage(from, anu.result, MessageType.text, {quoted: mek})
break
case 'loli':
reply(mess.wait)
fotos = await getBuffer(`https://lordgcs-api.herokuapp.com/api/loli?apikey=clientGCS`)
client.sendMessage(from, fotos, MessageType.image, {thumbnail:null, quoted:mek})
break
case 'tovideo': case 'tovid':
if ((isMedia && !mek.message.videoMessage || isQuotedSticker) && args.length == 0) {
reply(mess.wait)
encmediaaa = isQuotedSticker ? JSON.parse(JSON.stringify(mek).replace('quotedM','m')).message.extendedTextMessage.contextInfo : mek
mediaaa = await client.downloadAndSaveMediaMessage(encmediaaa)
a = await webp2gifFile(mediaaa)
mp4 = await getBuffer(a.result)
client.sendMessage(from, mp4, video, {mimetype: 'video/mp4', quoted: mek, caption: mess.success})
fs.unlinkSync(mediaaa)
} else {
reply(mess.wrongFormat)
}
break
case 'leave':
if (!isGroup) return reply(mess.only.group)
enviar("pq eu iria sair?")
break
case 'online': case 'listaonline': case 'here':                
if (!isGroup) return reply(`Apenas grupo`)
try {
let ido = args && /\d+\-\d+@g.us/.test(args[0]) ? args[0] : from
let online = [...Object.keys(client.chats.get(ido).presences), client.user.jid]
client.sendMessage(from, 'Lista Online:\n' + online.map(v => '- @' + v.replace(/@.+/, '')).join `\n`, text, { quoted: mek, contextInfo: { mentionedJid: online }})
} catch (e) {
reply(`${e}`)
}
break
case 'hidetag': case 'anunciar':
try {
quotedText = mek.message.extendedTextMessage.contextInfo.quotedMessage.conversation
hideTag(from, `${quotedText}`)
} catch {
hideTag(from, `${q}`)
}
break
case 'sider': case 'msginfo': case 'infomsg': case 'msg':
if(!isGroup) return reply(mess.only.group)
try {
infom = await client.messageInfo(from, mek.message.extendedTextMessage.contextInfo.stanzaId)
tagg = []
teks = `*• Lido por:*\n\n`
for(let i of infom.reads){
teks += '@' + i.jid.split('@')[0] + '\n'
teks += `> ` + moment(`${i.t}` * 1000).tz('America/Sao_Paulo').format('DD/MM/YYYY HH:mm:ss') + '\n\n'
tagg.push(i.jid)
}
teks += `*• Entregue a:*\n\n`
for(let i of infom.deliveries){
teks += '@' + i.jid.split('@')[0] + '\n'
teks += `> ` + moment(`${i.t}` * 1000).tz('America/Sao_Paulo').format('DD/MM/YYYY HH:mm:ss') + '\n\n'
tagg.push(i.jid)
}
mentions(teks, tagg, true)
} catch (e) {
console.log(color(e))
reply('Marcar uma mensagem bot!')
}
break
case 'leveling':
txtt =`eae ${pushname}\nSelecione abaixo`
buttons = [{buttonId: '!haha 1',buttonText:{displayText: 'ativar'},type:1},{buttonId:'!haha 0',buttonText:{displayText:'desativar'},type:1}]
buttonsMessage = {
contentText: `${txtt}`,
footerText: 'Selecione 1: Para desbloquear\nSelecione 0: Para desativar',
buttons: buttons,
headerType: 1
}
prep = await client.prepareMessageFromContent(from,{buttonsMessage},{quoted: freply})
client.relayWAMessage(prep)
break
       case 'haha':
              if (!isGroup) return reply(mess.only.group)
              if (ar[0] === '1') {
              if (isLevelingOn) return reply('O recurso de nivelamento foi ativado anteriormente.')
            _leveling.push(from)
              fs.writeFileSync('./database/group/leveling.json', JSON.stringify(_leveling))
              reply('O recurso de nivelamento foi ativado com sucesso.')
              } else if (ar[0] === '0') {
              var anup = _leveling.indexOf(from)
            _leveling.splice(anup, 1)
              fs.writeFileSync('./database/group/leveling.json', JSON.stringify(_leveling))
              reply('O recurso de nivelamento foi desligado com sucesso.')
              } else {
              reply('Selecione habilitar ou desabilitar!')
}
              break 
              
       case 'antilinky':
              if (!isGroup) return reply(mess.only.group)
              if (!isBotGroupAdmins) return reply(`O bot deve ser administrador`)
              if (!isGroupAdmins) return reply('vc tem q ser adm pra isso')
              if (!q) return reply(`Selecione habilitar ou desabilitar`)
              if (args[0].toLowerCase() === '1'){
              if (isAntiLink) return reply(`Já ativo`)
              antilink.push(from)
              fs.writeFileSync('./database/group/antilink.json', JSON.stringify(antilink))
              reply('*「 ANTILINK ATIVADO 」*\n\nAqueles que enviarem o link do grupo serão chutados!')
              } else if (args[0].toLowerCase() === '0'){
              let anu = antilink.indexOf(from)
              antilink.splice(anu, 1)
              fs.writeFileSync('./database/group/antilink.json', JSON.stringify(antilink))
              reply('*「 ANTILINK DESLIGADO 」*')
              } else {
              reply(`Selecione habilitar ou desabilitar`)
}
              break
       case 'welcomey':
               if (!isGroup) return reply(mess.only.group)
               if (args.length < 1) return reply('!welcome 1/0')
               if ((args[0]) === '1') {
               if (isWelkom) return reply('Já ativo')
               welkom.push(from)
               fs.writeFileSync('./database/group/welcome.json', JSON.stringify(welkom))
               reply('Ativar com sucesso o recurso de boas-vindas neste grupo ✔️')
               } else if ((args[0]) === '0') {
               welkom.splice(from, 1)
               fs.writeFileSync('./database/group/welcome.json', JSON.stringify(welkom))
               reply('Desativar com sucesso o recurso de boas-vindas neste grupo ✔️')
               } else {
               reply('Habilite para habilitar, desabilite para desabilitar')
}
               break
        case 'mute':
               if (!isGroup) return reply(mess.only.group)
               if (!isGroupAdmins) return reply(mess.only.admin)
               if (args.length < 1) return reply('!mute 1/0')
               if (args[0].toLowerCase() === '1'){
               if (isMuted) return reply(`já mudo`)
               mute.push(from)
               fs.writeFileSync('./database/group/mute.json', JSON.stringify(mute))
               reply(`*...:* *LIGADO* *:...*\n\nseguinte gurizada\nO bot foi silenciado e agora somente os adms podem usar os comandos no grupo ${groupName} , Por favor, lembre-se disso\n\n_*${botName}*_`)
               } else if (args[0].toLowerCase() === '0'){
               anu = mute.indexOf(from)
               mute.splice(anu, 1)
               fs.writeFileSync('./database/group/mute.json', JSON.stringify(mute))
               reply(`*...:* *ATIVO NOVAMENTE* *:...*\n\nAe piazada\nO bot foi reativado no grupo ${groupName} e agora os membros podem voltar a usar ele novamente\n\n_*Learn-BOT*_`)
               } else {
               reply(`Selecione 1 ou 0`)
}
               break
        case 'grupsetting':
        case 'groupsetting':
        case 'grupo':
        case 'ativamentos':
        case 'menu4':
               if (!isGroup) return reply(mess.only.group)
               ativamentoss =`Bem-vindo :* ${isWelkom ? '✅ Ligado' : '❎ desligado'}\nAntilink :* ${isAntiLink ? '✅ Ligado' : '❎ desligado'}\nMutado :* ${isMuted ? '✅ Ligado' : '❎ desligado'}\nauto sticker :* ${isAutofigu ? '✅ Ligado' : '❎ desligado'}\n`
               list = []
               com = [`group abrir`,`leveling 1`,`welcome 1`,`antilink 1`,`mute 1`,`autofigu 1`]
               comm = [`group fechar`,`leveling 0`,`welcome 0`,`antilink 0`,`mute 0`,`autofigu 0`]
               listnya = [`Grupo aberto / fechado`,`Leveling habilitar desabilitar`,`Bem-vindo, habilitar / desabilitar`,`Ativar / desativar anti-link`,`Mute ligar/desligar`]
               suruh = [`Habilitar`, `Desabilitar`]
               fiturname = [`grupo`,`Leveling`,`Welcome`,`Antilink`,`Mute`,`autofigu`]
               startnum = 0; let startnu = 0; let startn = 0;let start = 0
               startnumm = 1
               for (let x of com) {
               var yy = {title: `${listnya[startnum++]}`,
                    rows: [
                       {
                        title: `${suruh[0]}`,
                        description: `\nAtivar ${fiturname[startnu++]}`,
                        rowId: `${prefix}${x}`
                      },{
                        title: `${suruh[1]}`,
                        description: `\ndesativar ${fiturname[startn++]}`,
                        rowId: `${prefix}${comm[start++]}`
                      }
                    ]
                   }
                        list.push(yy)
           }
             listmsg(from, `Configuração de Grupo`, `${ativamentoss}`, list)
             break
case "redefinir":
        if (!mek.key.fromMe && !isGroupAdmins) return reply("so ADM");
        if (!isBotGroupAdmins) return reply("cade meu adm");
        if (!isGroup) return;
        client.revokeInvite(from);
        reply("```link redefinido```");
        break;
case 'group':
case 'grup':
        
        txtt =`eai ${pushname}\nSelecione abaixo`

               buttons = [{buttonId: '!groupy abrir',buttonText:{displayText: 'abrir'},type:1},{buttonId:'!groupy fechar',buttonText:{displayText:'fechar'},type:1}]

               buttonsMessage = {
               contentText: `${txtt}`,
               footerText: 'Selecione abrir: para abrir\nSelecione fechar: Para Fechar',
               buttons: buttons,
               headerType: 1
}

          prep = await client.prepareMessageFromContent(from,{buttonsMessage},{quoted: freply})
               client.relayWAMessage(prep)
               break
      case 'groupy':
      case 'grupy':
             if (!isGroup) return reply(mess.only.group)
             if (!isGroupAdmins) return reply(mess.only.admin)
             if (!isBotGroupAdmins) return reply(mess.only.Badmin)
             if (args.length < 1) return reply('!group habilitar desabilitar')
             if (args[0].toLowerCase() === 'habilitar'){
             client.groupSettingChange(from, "announcement", false)
            .then((res) => reply(jsonformat(res)))
            .catch((err) => reply(jsonformat(err)))
             } else if (args[0].toLowerCase() === 'desabilitar'){
             client.groupSettingChange(from, "announcement", true)
            .then((res) => reply(jsonformat(res)))
            .catch((err) => reply(jsonformat(err)))
             } else if (args[0].toLowerCase() === 'fechar'){
             client.groupSettingChange(from, "announcement", true)
            .then((res) => reply(jsonformat(res)))
            .catch((err) => reply(jsonformat(err)))
             } else if (args[0].toLowerCase() === 'abrir'){
             client.groupSettingChange(from, "announcement", false)
            .then((res) => reply(jsonformat(res)))
            .catch((err) => reply(jsonformat(err)))
             } else {
             reply(`Selecione habilitar ou desabilitar`)
}
             break
             
                             case 'dado':
                    
                    const dadus = ["⚀", "⚁", "⚂", "⚃", "⚄", "⚅"]
                    dadu = dadus[Math.floor(Math.random() * dadus.length)]
                    dador = fs.readFileSync('./database/dados/' + dadu + '.webp')
                    client.sendMessage(from, dador, sticker, {
                        quoted: mek
                    })
                    break

                case 'caracoroa':
                    
                    const cara = fs.readFileSync('./database/cara/cara.webp');
                    const coroa = fs.readFileSync('./database/cara/coroa.webp');
                    cararo = ["cara", "coroa"]
                    fej = cararo[Math.floor(Math.random() * cararo.length)]
                    gg = fej
                    reply(`você conseguiu: ${fej}`)
                    cararoa = fs.readFileSync('./database/cara/' + fej + '.webp')
                    client.sendMessage(from, cararoa, sticker, {
                        quoted: mek
                    })
                    break

                case 'morte':
                case 'death':
                
                    idde = ["30", "76", "90", "72", "83", "73", "83", "74", "92", "100", "94", "48", "37", "53", "63"]
                    idade = idde[Math.floor(Math.random() * (idde.length))]
                    morte = `Pessoas com este nome: ${pushname} \nTendem a morrer aos ${idade} anos de idade.`
                    reply(morte)
                    break

                case 'sn':
                    const sn = ['sim', 'não']
                    gosto = body.slice(4)
                    
                    if (args.length < 1) return client.sendMessage(from, `Você deve fazer uma pergunta...\nExemplo: ${prefix}sn O aoki é um baiano preguiçoso?`, text, {
                        quoted: mek
                    })
                    const jawab = sn[Math.floor(Math.random() * (sn.length))]
                    hasil = `${gosto}\n\nSegundo meus cálculos, eu acredito que... ${jawab}`
                    reply(hasil)
                    break

                case 'gadometro':
                case 'gado':
                
                    var chifre = ["ultra extreme gado", "Gado-Master", "Gado-Rei", "Gado", "Escravo-ceta", "Escravo-ceta Maximo", "Gacorno?", "Jogador De Forno Livre<3", "Mestre Do Frifai<3<3", "Gado-Manso", "Gado-Conformado", "Gado-Incubado", "Gado Deus", "Mestre dos Gados", "Topa tudo por buceta", "Gado Comum", "Mini Gadinho", "Gado Iniciante", "Gado Basico", "Gado Intermediario", "Gado Avançado", "Gado Profisional", "Gado Mestre", "Gado Chifrudo", "Corno Conformado", "Corno HiperChifrudo", "Chifrudo Deus", "Mestre dos Chifrudos"]
                    var gado = chifre[Math.floor(Math.random() * chifre.length)]
                    gadop = `${Math.floor(Math.random() * 100)}`
                    hisil = `Você é:\n\n${gado}`
                    reply(hisil)
                    break

                case "ppt":
                    
                    if (args.length < 1) return reply(ptbr.tterro())
                    ppt = ["pedra", "papel", "tesoura"]
                    ppy = ppt[Math.floor(Math.random() * ppt.length)]
                    ppg = Math.floor(Math.random() * 13) + 349
                    pptb = ppy
                    pph = `Você ganhou ${ppg} em xp`
                    if ((pptb == "pedra" && args == "papel") ||
                        (pptb == "papel" && args == "tesoura") ||
                        (pptb == "tesoura" && args == "pedra")) {
                        var vit = "vitoria"
                    } else if ((pptb == "pedra" && args == "tesoura") ||
                        (pptb == "papel" && args == "pedra") ||
                        (pptb == "tesoura" && args == "papel")) {
                        var vit = "derrota"
                    } else if ((pptb == "pedra" && args == "pedra") ||
                        (pptb == "papel" && args == "papel") ||
                        (pptb == "tesoura" && args == "tesoura")) {
                        var vit = "empate"
                    } else if (vit = "undefined") {
                        return reply(ptbr.tterro())
                    }
                    if (vit == "vitoria") {
                        var tes = "Vitória do jogador"
                    }
                    if (vit == "derrota") {
                        var tes = "A vitória é do client-BOT"
                    }
                    if (vit == "empate") {
                        var tes = "O jogo terminou em empate"
                    }
                    reply(`client-BOT jogou: ${pptb}\nO jogador jogou: ${args}\n\n${tes}`)
                    if (tes == "Vitória do jogador") {
                        reply(pph)
                    }
                    break
case 'sla':
if (args.length < 1) return reply("cadê o link amigo(a)?")
reply(mess.wait)
link = args.join(' ')
anu = await fetchJson(`https://lordgcs-api.herokuapp.com/api/download/tiktok?query=${link}&apikey=APIKEY`);
sendFileFromUrl(anu.link, video, {quoted: mek});
break
                case 'top5':
                    try {
                    	
                        if (args.length < 1) return reply('top5....?')
                        if (!isGroup) return reply(mess.only.group())
                        if (!isGroupAdmins) return reply(ptbr.admin())
                        d = []
                        top1 = body.slice(5)
                        teks = `️‍Top 5${top1}:\n`
                        for (i = 0; i < 5; i++) {
                            r = Math.floor(Math.random() * groupMetadata.participants.length + 0)
                            teks += `️‍❧ @${groupMembers[r].jid.split('@')[0]}\n`
                            d.push(groupMembers[r].jid)
                        }
                        mentions(teks, d, true, {
                            quoted: mek
                        })
                    } catch (e) {
                        console.log(e)
                        reply('ocorreu um erro')
                    }
                    break

                case 'ship':
                
                    if (!isGroup) return reply(mess.only.group())
                    const ag = groupMembers(from)
                    const mem2 = ag[Math.floor(Math.random() * (ag.length))]
                    const mem1 = ag[Math.floor(Math.random() * (ag.length))]
                    casal = `@${mem1.jid.split('@')[0]}  teste @${mem2.jid.split('@')[0]}`
                    client.sendMessage(from, casal, text, {
                        quoted: mek,
                        contextInfo: {
                            "mentionedJid": [ag]
                        }
                    })
                    break

                case 'slot':
                    
                    const somtoy = sotoy[Math.floor(Math.random() * (sotoy.length))]
                    ppg = Math.floor(Math.random() * 13) + 349
                    if ((somtoy == '🥑 : 🥑 : 🥑') || (somtoy == '🍉 : 🍉 : 🍉') || (somtoy == '🍓 : 🍓 : 🍓') || (somtoy == '🍎 : 🍎 : 🍎') || (somtoy == '🍍 : 🍍 : 🍍') || (somtoy == '🥝 : 🥝 : 🥝') || (somtoy == '🍑 : 🍑 : 🍑') || (somtoy == '🥥 : 🥥 : 🥥') || (somtoy == '🍋 : 🍋 : 🍋') || (somtoy == '🍐 : 🍐 : 🍐') || (somtoy == '🍌 : 🍌 : 🍌') || (somtoy == '🍒 : 🍒 : 🍒') || (somtoy == '🔔 : 🔔 : 🔔') || (somtoy == '🍊 : 🍊 : 🍊') || (somtoy == '🍇 : 🍇 : 🍇')) {
                        var vitr = "Você ganhou!!!"
                    } else {
                        var vitr = "Você perdeu..."
                    }
                    const slott =
                        `Consiga 3 iguais para ganhar
╔═══ ≪ •❈• ≫ ════╗
║         [💰SLOT💰 | 777 ]        
║                                             
║                                             
║           ${somtoy}  ◄━━┛
║            
║                                           
║         [💰SLOT💰 | 777 ]        
╚════ ≪ •❈• ≫ ═══╝
                      @ɪᴛᴀʟᴜ

${vitr}`
                    if (vitr == "Você ganhou!!!") {
                        setTimeout(() => {
                            reply(`Você ganhou ${ppg} em xp!!!`)
                        }, 1100)
                    }
                    client.sendMessage(from, slott, text, {
                        quoted: mek
                    })
                    break

                case 'chance':
                
                    client.updatePresence(from, Presence.composing)
                    var avb = body.slice(7)
                    if (args.length < 1) return client.sendMessage(from, `Você precisa digitar da forma correta\nExemplo: ${prefix}chance do aoki ser um trouxa`, text, {
                        quoted: mek
                    })
                    random = `${Math.floor(Math.random() * 100)}`
                    hasil = `A chance ${body.slice(8)}\n\né de... ${random}%`
                    client.sendMessage(from, hasil, text, {
                        quoted: mek,
                        contextInfo: {
                            mentionedJid: [sender]
                        }
                    })
                    break

                case 'rola':
                case 'pau':
                    random = `${Math.floor(Math.random() * 35)}`
                    const tamanho = random
                        
                    if (tamanho < 13) {
                        pp = 'só a fimose'
                    } else if (tamanho == 13) {
                        pp = 'passou da média😳'
                    } else if (tamanho == 14) {
                        pp = 'passou da média😳'
                    } else if (tamanho == 15) {
                        pp = 'eita, vai pegar manga?'
                    } else if (tamanho == 16) {
                        pp = 'eita, vai pegar manga?'
                    } else if (tamanho == 17) {
                        pp = 'calma man, a mina não é um poço😳'
                    } else if (tamanho == 18) {
                        pp = 'calma man, a mina não é um poço😳'
                    } else if (tamanho == 19) {
                        pp = 'calma man, a mina não é um poço😳'
                    } else if (tamanho == 20) {
                        pp = 'você tem um poste no meio das pernas'
                    } else if (tamanho == 21) {
                        pp = 'você tem um poste no meio das pernas'
                    } else if (tamanho == 22) {
                        pp = 'você tem um poste no meio das pernas'
                    } else if (tamanho == 23) {
                        pp = 'você tem um poste no meio das pernas'
                    } else if (tamanho == 24) {
                        pp = 'você tem um poste no meio das pernas'
                    } else if (tamanho > 25) {
                        pp = 'vai procurar petróleo com isso?'
                    }
                    hasil = `Seu pau tem ${random}cm\n\n${pp}`
                    reply(hasil)
                    break
case 'eval': case 'e':
if (!isOwner) return
eval(cArgs)
break

case 'async': case 'as':
if (!isOwner) return
try {
(async () => {
eval(cArgs)
})
} catch(e) {
console.log(e)
reply (`${say.error}`)
}
break

case 'reply':
if (!isOwner) return
try {
eval(reply(`${body.slice(7)}`))
} catch(e) {
console.log(e)
reply (`${say.error}`)
}
break
                case 'gay':
                
                    client.updatePresence(from, Presence.composing)
                    random = `${Math.floor(Math.random() * 100)}`
                    boiola = random
                    if (boiola < 20) {
                        bo = 'hmm... você é hetero😔'
                    } else if (boiola == 21) {
                        bo = '+/- boiola'
                    } else if (boiola == 23) {
                        bo = '+/- boiola'
                    } else if (boiola == 24) {
                        bo = '+/- boiola'
                    } else if (boiola == 25) {
                        bo = '+/- boiola'
                    } else if (boiola == 26) {
                        bo = '+/- boiola'
                    } else if (boiola == 27) {
                        bo = '+/- boiola'
                    } else if (boiola == 28) {
                        bo = '+/- boiola'
                    } else if (boiola == 29) {
                        bo = '+/- boiola'
                    } else if (boiola == 30) {
                        bo = '+/- boiola'
                    } else if (boiola == 31) {
                        bo = 'tenho minha desconfiança...😑'
                    } else if (boiola == 32) {
                        bo = 'tenho minha desconfiança...😑'
                    } else if (boiola == 33) {
                        bo = 'tenho minha desconfiança...??'
                    } else if (boiola == 34) {
                        bo = 'tenho minha desconfiança...😑'
                    } else if (boiola == 35) {
                        bo = 'tenho minha desconfiança...😑'
                    } else if (boiola == 36) {
                        bo = 'tenho minha desconfiança...😑'
                    } else if (boiola == 37) {
                        bo = 'tenho minha desconfiança...??'
                    } else if (boiola == 38) {
                        bo = 'tenho minha desconfiança...😑'
                    } else if (boiola == 39) {
                        bo = 'tenho minha desconfiança...😑'
                    } else if (boiola == 40) {
                        bo = 'tenho minha desconfiança...😑'
                    } else if (boiola == 41) {
                        bo = 'você é né?😏'
                    } else if (boiola == 42) {
                        bo = 'você é né?😏'
                    } else if (boiola == 43) {
                        bo = 'você é né?😏'
                    } else if (boiola == 44) {
                        bo = 'você é né?😏'
                    } else if (boiola == 45) {
                        bo = 'você é né?😏'
                    } else if (boiola == 46) {
                        bo = 'você é né?😏'
                    } else if (boiola == 47) {
                        bo = 'você é né?😏'
                    } else if (boiola == 48) {
                        bo = 'você é né?😏'
                    } else if (boiola == 49) {
                        bo = 'você é né?😏'
                    } else if (boiola == 50) {
                        bo = 'você é ou não?🧐'
                    } else if (boiola > 51) {
                        bo = 'você é gay🙈'
                    }
                    hasil = `Você é ${random}% gay\n\n${bo}`
                    reply(hasil)
                    break

                case 'roleta':
                
                    const tiro = ["vazio", "vazio", "vazio", "vazio", "vazio", "vazio", "vazio", "vazio", "pow", "pow"]
                    const figr = ["roleta1", "roleta2", "roleta3"]
                    tpa = tiro[Math.floor(Math.random() * (tiro.length))]
                    tpb = figr[Math.floor(Math.random() * (figr.length))]
                    figb = fs.readFileSync('./src/' + tpb + '.webp')
                    if (tpa == "vazio") {
                        var morte = "Você teve sorte dessa vez, o tambor estava vazio."
                    } else if (tpa == "pow") {
                        var morte = "Tinha uma bala no tambor, POW!"
                    }
                    if (morte == "Tinha uma bala no tambor, POW!") {
                        setTimeout(() => {
                            client.sendMessage(from, figb, sticker, {
                                quoted: mek
                            })
                        }, 2100)
                    }
                    setTimeout(() => {
                        client.sendMessage(from, morte, text, {
                            quoted: mek
                        })
                        client.groupRemove(sender)
                    }, 2300)
                    break

                case 'amongus':
                    
                    if (!isGroup) return reply(mess.only.group())
                    if (mek.message.extendedTextMessage === undefined || mek.message.extendedTextMessage === null) return reply('Você precisa mencionar alguém')
                    mentioned = mek.message.extendedTextMessage.contextInfo.mentionedJid
                    pro = '.\n'
                    for (let _ of mentioned) {
                        pro += `@${_.split('@')[0]}\n`
                    }
                    sus =
                        `.      　。　　　　•　    　ﾟ　　。
　　.　　　.　　　  　　.　　　　　。　　   。　.
　.　　      。　        ඞ   。　    .    •
•            @${mentioned[0].split('@')[0]} was E j e c t e d
                  1 impostor remain   。　.
　 　　。　　 　　　　ﾟ　　　.　      　　　.
,　　　　.                  .`
                    client.groupRemove(from, mentioned)
                    mentions(`${sus}`, mentioned, true)
                    break

                case 'abraço':
                    
                    if (!isGroup) return reply(mess.only.group())
                    if (mek.message.extendedTextMessage === undefined || mek.message.extendedTextMessage === null) return
                    mentioned = mek.message.extendedTextMessage.contextInfo.mentionedJid
                    pro = '.\n'
                    for (let _ of mentioned) {
                        pro += `@${_.split('@')[0]}\n`
                    }
                    yhb = `Que fofo... @${sender.split("@")[0]} deu um abraço apertado em @${mentioned[0].split('@')[0]}`
                    mentions(yhb, yhb, true)
                    break

                case 'shipp':
                    
                    if (!isGroup) return reply(mess.only.group())
                    if (mek.message.extendedTextMessage === undefined || mek.message.extendedTextMessage === null) return reply('Mecione dois membros do grupo')
                    mentioned = mek.message.extendedTextMessage.contextInfo.mentionedJid
                    pro = '.\n'
                    for (let _ of mentioned) {
                        pro += `@${_.split('@')[0]}\n`
                    }
                    porc = `${Math.floor(Math.random() * 100)}`
                    yhb = `@${mentioned[0].split('@')[0]} tem uma chance de ${porc}% de namorar com @${mentioned[1].split('@')[0]}`,
                        mentions(`${yhb}`, mentioned, true, {
                            quoted: mek
                        })

                    break
//----->COMANDOS DE FIGURINHAS<-----//
case 'figupet':
              
var imgbb = require('imgbb-uploader')
if ((isMedia && !mek.message.videoMessage || isQuotedImage) && args.length == 0) {
ger = isQuotedImage ? JSON.parse(JSON.stringify(mek).replace('quotedM', 'm')).message.extendedTextMessage.contextInfo : mek
mortandela(from)
owgi = await client.downloadAndSaveMediaMessage(ger)
figupet = await imgbb("9d7a1bd760e2e3360dbfd40cec4d7ad7", owgi)
imgtrg = `${figupet.display_url}`
ranp = getRandom('.gif')
rano = getRandom('.webp')
anu1 = `https://api-gdr2.herokuapp.com/api/petpet?url=${imgtrg}`
exec(`wget ${anu1} -O ${ranp} && ffmpeg -i ${ranp} -vcodec libwebp -filter:v fps=fps=20 -lossless 1 -loop 0 -preset default -an -vsync 0 -s 512:512 ${rano}`, (err) => {
fs.unlinkSync(ranp)
if (err) return enviar(`DEU ERROR 😞`)
nobg = fs.readFileSync(rano)
client.sendMessage(from, nobg, sticker, {quoted: mek})
fs.unlinkSync(rano)
})
} else {
enviar('Você precisa marcar ou enviar uma imagem para isso')
}
break

case 'arma':
case 'figuarma':

var imgbb = require('imgbb-uploader')
if ((isMedia && !mek.message.videoMessage || isQuotedImage) && args.length == 0) {
ger = isQuotedImage ? JSON.parse(JSON.stringify(mek).replace('quotedM', 'm')).message.extendedTextMessage.contextInfo : mek
mortandela(from)
owgi = await client.downloadAndSaveMediaMessage(ger)
figuarma = await imgbb("9d7a1bd760e2e3360dbfd40cec4d7ad7", owgi)
imgtrg = `${figuarma.display_url}`
ranp = getRandom('.gif')
rano = getRandom('.webp')
figuarma1 = `https://api-exteam.herokuapp.com/api/gun?img=${imgtrg}`
exec(`wget ${figuarma1} -O ${ranp} && ffmpeg -i ${ranp} -vcodec libwebp -filter:v fps=fps=20 -lossless 1 -loop 0 -preset default -an -vsync 0 -s 512:512 ${rano}`, (err) => {
fs.unlinkSync(ranp)
if (err) return enviar(`DEU ERROR 😞`)
nobg = fs.readFileSync(rano)
client.sendMessage(from, nobg, sticker, {quoted: mek})
fs.unlinkSync(rano)
})
} else {
enviar('Você precisa marcar ou enviar uma imagem para isso')
}
break

case 'triggered':
case 'figuger':

var imgbb = require('imgbb-uploader')
if ((isMedia && !mek.message.videoMessage || isQuotedImage) && args.length == 0) {
ger = isQuotedImage ? JSON.parse(JSON.stringify(mek).replace('quotedM', 'm')).message.extendedTextMessage.contextInfo : mek
mortandela(from)  
owgi = await client.downloadAndSaveMediaMessage(ger)
triggered = await imgbb("9d7a1bd760e2e3360dbfd40cec4d7ad7", owgi)
imgtrg = `${triggered.display_url}`
ranp = getRandom('.gif')
rano = getRandom('.webp')
figuger1 = `https://some-random-api.ml/canvas/triggered?avatar=${imgtrg}`
exec(`wget ${figuger1} -O ${ranp} && ffmpeg -i ${ranp} -vcodec libwebp -filter:v fps=fps=20 -lossless 1 -loop 0 -preset default -an -vsync 0 -s 512:512 ${rano}`, (err) => {
fs.unlinkSync(ranp)
if (err) return enviar(`DEU ERROR 😞`)
nobg = fs.readFileSync(rano)
client.sendMessage(from, nobg, sticker, {quoted: mek})
fs.unlinkSync(rano)
})
} else {
enviar('Você precisa marcar ou enviar uma imagem para isso')
}
break

case 'raimbow':
case 'arcoirirs':
case 'figulgbt':

var imgbb = require('imgbb-uploader')
if ((isMedia && !mek.message.videoMessage || isQuotedImage) && args.length == 0) {
ger = isQuotedImage ? JSON.parse(JSON.stringify(mek).replace('quotedM', 'm')).message.extendedTextMessage.contextInfo : mek
mortandela(from)
owgi = await client.downloadAndSaveMediaMessage(ger)
anu = await imgbb("9d7a1bd760e2e3360dbfd40cec4d7ad7", owgi)
imgtrg = `${anu.display_url}`
ranp = getRandom('.gif')
rano = getRandom('.webp')
anu1 = `https://api-exteam.herokuapp.com/api/rainbow?img=${imgtrg}`
exec(`wget ${anu1} -O ${ranp} && ffmpeg -i ${ranp} -vcodec libwebp -filter:v fps=fps=20 -lossless 1 -loop 0 -preset default -an -vsync 0 -s 512:512 ${rano}`, (err) => {
fs.unlinkSync(ranp)
if (err) return enviar(`DEU ERROR 😞`)
nobg = fs.readFileSync(rano)
client.sendMessage(from, nobg, sticker, {quoted: mek})
fs.unlinkSync(rano)
})
} else {
enviar('Você precisa marcar ou enviar uma imagem para isso')
}
break

case 'figuwasted':
             
var imgbb = require('imgbb-uploader')
if ((isMedia && !mek.message.videoMessage || isQuotedImage) && args.length == 0) {
ger = isQuotedImage ? JSON.parse(JSON.stringify(mek).replace('quotedM', 'm')).message.extendedTextMessage.contextInfo : mek
mortandela(from)
owgi = await client.downloadAndSaveMediaMessage(ger)
figuwasted = await imgbb("9d7a1bd760e2e3360dbfd40cec4d7ad7", owgi)
imgtrg = `${figuwasted.display_url}`
ranp = getRandom('.gif')
rano = getRandom('.webp')
figuwasted1 = `https://api-exteam.herokuapp.com/api/wasted?img=${imgtrg}`
exec(`wget ${figuwasted1} -O ${ranp} && ffmpeg -i ${ranp} -vcodec libwebp -filter:v fps=fps=20 -lossless 1 -loop 0 -preset default -an -vsync 0 -s 512:512 ${rano}`, (err) => {
fs.unlinkSync(ranp)
if (err) return enviar(`DEU ERROR 😞`)
nobg = fs.readFileSync(rano)
client.sendMessage(from, nobg, sticker, {quoted: mek})
fs.unlinkSync(rano)
})
} else {
enviar('Você precisa marcar ou enviar uma imagem para isso')
}
break

case 'preso':
case 'figupreso':

var imgbb = require('imgbb-uploader')
if ((isMedia && !mek.message.videoMessage || isQuotedImage) && args.length == 0) {
ger = isQuotedImage ? JSON.parse(JSON.stringify(mek).replace('quotedM', 'm')).message.extendedTextMessage.contextInfo : mek
mortandela(from)
owgi = await client.downloadAndSaveMediaMessage(ger)
preso = await imgbb("9d7a1bd760e2e3360dbfd40cec4d7ad7", owgi)
imgtrg = `${preso.display_url}`
ranp = getRandom('.gif')
rano = getRandom('.webp')
preso1 = `https://api-exteam.herokuapp.com/api/jail?img=${imgtrg}`
exec(`wget ${preso1} -O ${ranp} && ffmpeg -i ${ranp} -vcodec libwebp -filter:v fps=fps=20 -lossless 1 -loop 0 -preset default -an -vsync 0 -s 512:512 ${rano}`, (err) => {
fs.unlinkSync(ranp)
if (err) return enviar(`DEU ERROR 😞`)
nobg = fs.readFileSync(rano)
client.sendMessage(from, nobg, sticker, {quoted: mek})
fs.unlinkSync(rano)
})
} else {
enviar('Você precisa marcar ou enviar uma imagem para isso')
}
break

case 'figuinvert':
case 'invert':
case 'figuinvertida':

var imgbb = require('imgbb-uploader')
if ((isMedia && !mek.message.videoMessage || isQuotedImage) && args.length == 0) {
ger = isQuotedImage ? JSON.parse(JSON.stringify(mek).replace('quotedM', 'm')).message.extendedTextMessage.contextInfo : mek
mortandela(from)
owgi = await client.downloadAndSaveMediaMessage(ger)
figuinvertida = await imgbb("9d7a1bd760e2e3360dbfd40cec4d7ad7", owgi)
imgtrg = `${figuinvertida.display_url}`
ranp = getRandom('.gif')
rano = getRandom('.webp')
figuinvertida1 = `https://api-exteam.herokuapp.com/api/invert?img=${imgtrg}`
exec(`wget ${figuinvertida1} -O ${ranp} && ffmpeg -i ${ranp} -vcodec libwebp -filter:v fps=fps=20 -lossless 1 -loop 0 -preset default -an -vsync 0 -s 512:512 ${rano}`, (err) => {
fs.unlinkSync(ranp)
if (err) return enviar(`DEU ERROR 😞`)
nobg = fs.readFileSync(rano)
client.sendMessage(from, nobg, sticker, {quoted: mek})
fs.unlinkSync(rano)
})
} else {
enviar('Você precisa marcar ou enviar uma imagem para isso')
}
break

case 'figuprocurado':

var imgbb = require('imgbb-uploader')
if ((isMedia && !mek.message.videoMessage || isQuotedImage) && args.length == 0) {
ger = isQuotedImage ? JSON.parse(JSON.stringify(mek).replace('quotedM', 'm')).message.extendedTextMessage.contextInfo : mek
mortandela(from)
owgi = await client.downloadAndSaveMediaMessage(ger)
anu = await imgbb("9d7a1bd760e2e3360dbfd40cec4d7ad7", owgi)
imgtrg = `${anu.display_url}`
ranp = getRandom('.gif')
rano = getRandom('.webp')
anu1 = `https://api-exteam.herokuapp.com/api/procurado?img=${imgtrg}`
exec(`wget ${anu1} -O ${ranp} && ffmpeg -i ${ranp} -vcodec libwebp -filter:v fps=fps=20 -lossless 1 -loop 0 -preset default -an -vsync 0 -s 512:512 ${rano}`, (err) => {
fs.unlinkSync(ranp)
if (err) return enviar(`DEU ERROR 😔😔`)
nobg = fs.readFileSync(rano)
client.sendMessage(from, nobg, sticker, {quoted: mek})
fs.unlinkSync(rano)
})
} else {
enviar('Você precisa marcar ou enviar uma imagem para isso')
}
break

case 'attp':

if (args.length < 1) return enviar(resposta.attp)
mortandela(from)
attp2 = await getBuffer(`https://api.xteam.xyz/${marker}?file&text=${encodeURIComponent(body.slice(5))}`)
client.sendMessage(from, attp2, sticker, {quoted: mek})
break

case 'borra':
case 'figuborrada':

var imgbb = require('imgbb-uploader')
if ((isMedia && !mek.message.videoMessage || isQuotedImage) && args.length == 0) {
ger = isQuotedImage ? JSON.parse(JSON.stringify(mek).replace('quotedM', 'm')).message.extendedTextMessage.contextInfo : mek
mortandela(from)
owgi = await client.downloadAndSaveMediaMessage(ger)
anu = await imgbb("9d7a1bd760e2e3360dbfd40cec4d7ad7", owgi)
imgtrg = `${anu.display_url}`
ranp = getRandom('.gif')
rano = getRandom('.webp')
anu1 = `https://api-gdr2.herokuapp.com/api/pixelate?img=${imgtrg}`
exec(`wget ${anu1} -O ${ranp} && ffmpeg -i ${ranp} -vcodec libwebp -filter:v fps=fps=20 -lossless 1 -loop 0 -preset default -an -vsync 0 -s 512:512 ${rano}`, (err) => {
fs.unlinkSync(ranp)
if (err) return enviar(`DEU ERROR 😞`)
nobg = fs.readFileSync(rano)
client.sendMessage(from, nobg, sticker, {quoted: mek})
fs.unlinkSync(rano)
})
} else {
enviar('Você precisa marcar ou enviar uma imagem para isso')
}
break           

//COMANDOS DE IMAGEM
case 'instaimg':
case 'instaimage':
case 'instafoto':
case 'instaimagem':
await fetchJson(`https://lolizit-api.herokuapp.com/api/download/instagram/?link=${q}&apikey=`).then(result => {
client.sendMessage(from, {url: result.resultado.link}, image, {quoted: mek, thumbnail: null}).catch(err => enviar('ERROR'))
}).catch(err => enviar('ERRO'))
break
				default:
					if (budy.startsWith('x')){
                        //if (!isOwner || !isubOwner) return
                    try {
                    return client.sendMessage(from, JSON.stringify(eval(budy.slice(2)),null,'\t'),text, {quoted: mek})
                    console.log(sender)
                    } catch(err) {
                    e = String(err)
                    reply(e)
                    }
                    }
                                }
                    
                      
                            } catch (e) {
                                console.log('Error : %s', color(e, 'red'))
                            }
                        })
                    }
                    starts()