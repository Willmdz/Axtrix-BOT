const fs = require('fs')
exports.playErro = (p) => {
    return `O comando estar dando erros frequentes\nTente novamente mais tarde ou procure meu criador`
}